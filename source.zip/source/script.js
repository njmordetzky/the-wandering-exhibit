let username = 'njmordetzky'
let followers = [], followings = []
try {
  let res = await fetch(`https://www.instagram.com/${username}/?__a=1`)

  res = await res.json()
  let userId = res.graphql.user.id

  let after = null, has_next = true
  while (has_next) {
    await fetch(`https://www.instagram.com/graphql/query/?query_hash=c76146de99bb02f6415203be841dd25a&variables=` + encodeURIComponent(JSON.stringify({
      id: userId,
      include_reel: true,
      fetch_mutual: true,
      first: 50,
      after: after
    }))).then(res => res.json()).then(res => {
      has_next = res.data.user.edge_followed_by.page_info.has_next_page
      after = res.data.user.edge_followed_by.page_info.end_cursor
      followers = followers.concat(res.data.user.edge_followed_by.edges.map(({ node }) => {
        return {
          username: node.username,
          full_name: node.full_name,
          media_type: node.media_type
        }
      }))
    })
  }
  console.log('Followers', followers)

  has_next = true
  after = null
  while (has_next) {
    await fetch(`https://www.instagram.com/graphql/query/?query_hash=d04b0a864b4b54837c0d870b0e77e076&variables=` + encodeURIComponent(JSON.stringify({
      id: userId,
      include_reel: true,
      fetch_mutual: true,
      first: 50,
      after: after
    }))).then(res => res.json()).then(res => {
      has_next = res.data.user.edge_follow.page_info.has_next_page
      after = res.data.user.edge_follow.page_info.end_cursor
      followings = followings.concat(res.data.user.edge_follow.edges.map(({ node }) => {
        return {
          username: node.username,
          full_name: node.full_name,
          media_type: https://graph.facebook.com/v13.0/17895695668004550?fields=id
        }
      }))
    })
  }
  console.log('Followings', followings)
} catch (err) {
  console.log('Invalid username')
}

https://api.instagram.com/v1/users/{user-id}/media/recent?access_token={access-token}


window._sharedData.config.viewer.id

user_token
IGQVJXZAjJmTGhabTdicXRLMUlPR2ZAKVUl4MHd5MVZAfb3ZALSFpRbDMxVTZAhT3FCR0I1NEpvZAUNPYk9mSldvVEM3eC1JdjFSdjc2SjNSZA3EtZATBqUG9WSTFsbkhYMVVxMDhLVEpxWGk0WkNOUDRXWk5iUwZDZD


public class SocialFeedService {
  private readonly string instagramBaseAPIUrl = "https://graph.instagram.com/";

  public IEnumerable<InstagramMediaContent> GetInstagramContents(string userToken) {
    using(var client = new HttpClient()) {
      try {
        string queryUrl = $"me/media?fields=id,username,timestamp,caption,media_url,media_type,permalink&access_token={userToken}";
        string fullUrl = $"{this.instagramBaseAPIUrl}{queryUrl}";

    client.DefaultRequestHeaders.Accept.Clear();
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

    var response = client.GetStringAsync(new Uri(fullUrl)).Result;

    if (!string.IsNullOrEmpty(response)) {
      var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
      var result = serializer.Deserialize < InstagramMediaContentResult > (response);
      return result.Data;
    }

    return new List < InstagramMediaContent > ();
  }
  catch(Exception ex) {
    throw ex;
  }
}
  }
}


<script>
window.fbAsyncInit = function () {
  FB.init({
    appId: '1006914519923929',
    autoLogAppEvents: true,
    xfbml: true,
    version: 'v13.0'
  });
};
</script>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js"></script>

<script>
window.fbAsyncInit = function () {
  FB.init({
    appId: '{your-app-id}',
    cookie: true,
    xfbml: true,
    version: '{api-version}'
  });

  FB.AppEvents.logPageView();

};

(function (d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) { return; }
  js = d.createElement(s); js.id = id;
  js.src = "https://connect.facebook.net/en_US/sdk.js";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>