let username = 'njmordetzky'
let followers = [], followings = []
try {
  let res = await fetch(`https://www.instagram.com/${username}/?__a=1`)

  res = await res.json()
  let userId = res.graphql.user.id

  let after = null, has_next = true
  while (has_next) {
    await fetch(`https://www.instagram.com/graphql/query/?query_hash=c76146de99bb02f6415203be841dd25a&variables=` + encodeURIComponent(JSON.stringify({
      id: userId,
      include_reel: true,
      fetch_mutual: true,
      first: 50,
      after: after
    }))).then(res => res.json()).then(res => {
      has_next = res.data.user.edge_followed_by.page_info.has_next_page
      after = res.data.user.edge_followed_by.page_info.end_cursor
      followers = followers.concat(res.data.user.edge_followed_by.edges.map(({ node }) => {
        return {
          username: node.username,
          full_name: node.full_name,
          media_type: node.media_type
        }
      }))
    })
  }
  console.log('Followers', followers)

  has_next = true
  after = null
  while (has_next) {
    await fetch(`https://www.instagram.com/graphql/query/?query_hash=d04b0a864b4b54837c0d870b0e77e076&variables=` + encodeURIComponent(JSON.stringify({
      id: userId,
      include_reel: true,
      fetch_mutual: true,
      first: 50,
      after: after
    }))).then(res => res.json()).then(res => {
      has_next = res.data.user.edge_follow.page_info.has_next_page
      after = res.data.user.edge_follow.page_info.end_cursor
      followings = followings.concat(res.data.user.edge_follow.edges.map(({ node }) => {
        return {
          username: node.username,
          full_name: node.full_name,
          media_type: https://graph.facebook.com/v13.0/17895695668004550?fields=id
        }
      }))
    })
  }
  console.log('Followings', followings)
} catch (err) {
  console.log('Invalid username')
}

https://api.instagram.com/v1/users/{user-id}/media/recent?access_token={access-token}


window._sharedData.config.viewer.id

user_token
IGQVJXZAjJmTGhabTdicXRLMUlPR2ZAKVUl4MHd5MVZAfb3ZALSFpRbDMxVTZAhT3FCR0I1NEpvZAUNPYk9mSldvVEM3eC1JdjFSdjc2SjNSZA3EtZATBqUG9WSTFsbkhYMVVxMDhLVEpxWGk0WkNOUDRXWk5iUwZDZD


public class SocialFeedService {
  private readonly string instagramBaseAPIUrl = "https://graph.instagram.com/";

  public IEnumerable<InstagramMediaContent> GetInstagramContents(string userToken) {
    using(var client = new HttpClient()) {
      try {
        string queryUrl = $"me/media?fields=id,username,timestamp,caption,media_url,media_type,permalink&access_token={userToken}";
        string fullUrl = $"{this.instagramBaseAPIUrl}{queryUrl}";

    client.DefaultRequestHeaders.Accept.Clear();
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

    var response = client.GetStringAsync(new Uri(fullUrl)).Result;

    if (!string.IsNullOrEmpty(response)) {
      var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
      var result = serializer.Deserialize < InstagramMediaContentResult > (response);
      return result.Data;
    }

    return new List < InstagramMediaContent > ();
  }
  catch(Exception ex) {
    throw ex;
  }
}
  }
}


<script>
window.fbAsyncInit = function () {
  FB.init({
    appId: '1006914519923929',
    autoLogAppEvents: true,
    xfbml: true,
    version: 'v13.0'
  });
};
</script>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js"></script>

<script>
window.fbAsyncInit = function () {
  FB.init({
    appId: '{your-app-id}',
    cookie: true,
    xfbml: true,
    version: '{api-version}'
  });

  FB.AppEvents.logPageView();

};

(function (d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) { return; }
  js = d.createElement(s); js.id = id;
  js.src = "https://connect.facebook.net/en_US/sdk.js";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>

Paste this into a browser to get an authorization code 
its short lived and will be valid for 1 hour only,
  When code expires just paste the URL in again to generate a new one
https://www.instagram.com/oauth/authorize?client_id=509631933891140&redirect_uri=https://nathanielmordetzky.com/&scope=user_profile,user_media&response_type=code

get the code from the URL youre redirected to: code = { this is your authorization code }#
https://nathanielmordetzky.com/?code=#_
AQDYr0unT_ - FUyVQL65mhYtBJ2Zf_yASn5tyAf1TRA1T - PYXA67dSenqC2AxZPav - GR8DxiLBPmo6v6MB4eMbr_0g2Pjv0QEduiW4WrFcL - ynLIZ44tLZXLRfmVWIBPuQeVag1lygVfi8HC3jPXDBL_DarU0TmjhQPmlvheADeIxyb6JsXP7EVoH167 - azQCCJn0pcOrq9pvnsAO1U1dndM7JO4fxGLlG52t2cVVoKPEIA

curl - X POST \
https://api.instagram.com/oauth/access_token \
-F client_id = 509631933891140  \
-F client_secret = 9720491097a3b7d940e619096dc1118f \
-F grant_type = authorization_code \
-F redirect_uri = https://nathanielmordetzky.com/ \
-F code = AQDYr0unT_ - FUyVQL65mhYtBJ2Zf_yASn5tyAf1TRA1T - PYXA67dSenqC2AxZPav - GR8DxiLBPmo6v6MB4eMbr_0g2Pjv0QEduiW4WrFcL - ynLIZ44tLZXLRfmVWIBPuQeVag1lygVfi8HC3jPXDBL_DarU0TmjhQPmlvheADeIxyb6JsXP7EVoH167 - azQCCJn0pcOrq9pvnsAO1U1dndM7JO4fxGLlG52t2cVVoKPEIA

{
  "access_token": "IGQVJWaWU2X3BUckM2X091aE9KdHBNM09wT0ZAaSE1WRkdDWk1pRlRUV0tEV3M5a0dQeDM0dXlCSF9tazAzX0o4WUFhR0FkQ0lHTVhJbWh5blBIZAERWZAl92T1ZAvcEp2ODlVTWtwN0pxSXQ3eEFTb2NYeE5LVmdCVHRmQk5ZA",
    "user_id": 17841403152081781
}

curl - X GET \
'https://graph.instagram.com/17841403152081781?fields=id,username&access_token=IGQVJWaWU2X3BUckM2X091aE9KdHBNM09wT0ZAaSE1WRkdDWk1pRlRUV0tEV3M5a0dQeDM0dXlCSF9tazAzX0o4WUFhR0FkQ0lHTVhJbWh5blBIZAERWZAl92T1ZAvcEp2ODlVTWtwN0pxSXQ3eEFTb2NYeE5LVmdCVHRmQk5ZA'

{ "id": "5663694586990910", "username": "njmordetzky" }

curl - i - X GET "https://graph.instagram.com/access_token?grant_type=ig_exchange_token&client_secret=9720491097a3b7d940e619096dc1118f&access_token=IGQVJWaWU2X3BUckM2X091aE9KdHBNM09wT0ZAaSE1WRkdDWk1pRlRUV0tEV3M5a0dQeDM0dXlCSF9tazAzX0o4WUFhR0FkQ0lHTVhJbWh5blBIZAERWZAl92T1ZAvcEp2ODlVTWtwN0pxSXQ3eEFTb2NYeE5LVmdCVHRmQk5ZA"

Longer 60 day Access Token
{
  "access_token": "IGQVJWZA3BieU5OWF9FbXVWS2kxN0Vzd1N6QkZAXcG8yN2VGS1RfRzB0STdqMi1wMVc0dXF6Nm5tMGV3MXROR0wteHJUaDBUUzZALWkZAKY3RiYTlxTzNsV3o5c0VzLTdxbzM4TThSbDl3",
    "token_type": "bearer",
      "expires_in": 5184000
}